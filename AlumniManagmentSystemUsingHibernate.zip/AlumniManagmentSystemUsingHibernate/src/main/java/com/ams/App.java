package com.ams;



public class App 
{

	
    public static void main( String[] args )
    {

    	CrudOperation.mainMenu();
    }
}
