package com.ams.exception;

@SuppressWarnings("serial")
public class GlobalException extends Exception {
	
	public GlobalException(String message)
	{
		super(message);
	}
	
}
